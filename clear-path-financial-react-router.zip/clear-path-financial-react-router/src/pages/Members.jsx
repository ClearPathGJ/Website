import React from 'react';

const Members = () => <section className='members'><h2>Members Area</h2><p>Toolkit access info here.</p></section>

export default Members;