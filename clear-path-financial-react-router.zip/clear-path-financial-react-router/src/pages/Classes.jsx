import React from 'react';

const Classes = () => <section className='classes'><h2>Classes</h2><p>Classes info here.</p></section>

export default Classes;