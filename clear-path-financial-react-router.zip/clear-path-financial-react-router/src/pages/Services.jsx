import React from 'react';

const Services = () => <section className='services'><h2>Our Services</h2><p>Service details go here.</p></section>

export default Services;