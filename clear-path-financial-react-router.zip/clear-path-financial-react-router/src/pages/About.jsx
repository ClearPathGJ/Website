import React from 'react';

const About = () => <section className='about'><h2>About Us</h2><p>Company info here.</p></section>

export default About;