import React from 'react';

const Blog = () => <section className='blog'><h2>Blog</h2><p>Blog posts go here.</p></section>

export default Blog;